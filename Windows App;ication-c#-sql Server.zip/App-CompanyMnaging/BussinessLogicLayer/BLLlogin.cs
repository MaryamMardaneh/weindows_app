﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinnessEntity;
using DataAccessLayer;

namespace BussinessLogicLayer
{
    public class BLLlogin
    {
        DALLogincs dallogin = new DALLogincs();
        public byte Login(string username,string password)
        {
            return dallogin.Login(username, password);
        }
        public void Register(login adm)
        {
            dallogin.Register(adm);
        }
    }
}
