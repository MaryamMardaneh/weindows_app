﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinnessEntity;
using DataAccessLayer;

namespace BussinessLogicLayer
{
    public class BLemp
    {
        DALemp dALemp = new DALemp();
        
        public string Create(Employee emp)
        {
            //check age range
            int this_year = DateTime.Now.Year;
            int bor_year = emp.DateofBirth.Year;
            if ((this_year - bor_year) < 18 || (this_year - bor_year) > 70)
            {
                return "The age of the applicant is more or less than the allowed limit";
            }
            else
            {
                return dALemp.Create(emp);
            }

        }
        
        public List<Employee> Read(string name)
        {
            return dALemp.Read(name);
        }
        public Employee Read(int id)
        {
            return dALemp.Read(id);
        }

        public List<Employee> Read()
        {
            return dALemp.Read();
        }

       public int GetRecord()
        {
            return dALemp.GetRecord();
        }

        public string Update(int id,Employee empNew)
        {
            return dALemp.Update(id, empNew);
        }

        public string Deleat(int id)
        {
            return dALemp.Deleat(id);
        }
    }
}