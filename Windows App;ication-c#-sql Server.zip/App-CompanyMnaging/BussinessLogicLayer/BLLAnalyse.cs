﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinnessEntity;
using DataAccessLayer;


namespace BussinessLogicLayer
{
    public class BLLAnalyse
    {
        dalAnalyse dalAnalyse = new dalAnalyse();
        public void Create(YearIncome income)
        {
            dalAnalyse.Create(income);
        }
        public List<double> Read()
        {
           return dalAnalyse.Read();
        }
    }
}
