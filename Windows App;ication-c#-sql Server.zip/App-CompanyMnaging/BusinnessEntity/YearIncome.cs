﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinnessEntity
{
    public class YearIncome
    {
        public int id { get; set; }
        public double Income { get; set; }
        public string Year { get; set; }

    }
}
