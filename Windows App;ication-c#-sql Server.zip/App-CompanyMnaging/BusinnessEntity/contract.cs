﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinnessEntity
{
     public  class contract
    {
        public int ID { get; set; }
        public string Project_name { get; set; }
        public string siret_number { get; set; }
        public byte Grade { get; set; }
        public string Type { get; set; }
        public string Price { get; set; }
        public DateTime start_date { get; set; }
        public DateTime Delivery_Date { get; set; }
        public string PicturePath { get; set; }
        public string projrct_ID { get; set; }
        public Clientes Clientes { get; set; }




    }

    //siret_number is the iD of the contract
}
