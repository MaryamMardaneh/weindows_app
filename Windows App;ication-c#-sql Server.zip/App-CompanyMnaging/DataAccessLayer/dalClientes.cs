﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using BusinnessEntity;

namespace DataAccessLayer
{
     public class dalClientes
    {
        DataBace db = new DataBace();
        //create a new membre
        public string Create(Clientes clnt)
        {
            if (!Read(clnt))
            {
                if (clnt.subscription_number.Length == 10)
                {
                    db.clientes.Add(clnt);
                    db.SaveChanges();
                    return "New Customer Successfully Registered!";
                }
                else
                {
                    return "The entered identification code is invalid";
                }
            }
            else
            {
                return "The Information Entered Is Already Existed!";
            }
        }
        //read all data
        public List<Clientes> Read()
        {
            return db.clientes.ToList();
        }
        //existing check
        public bool Read(Clientes clnt)
        {
            return db.clientes.Any(i => i.Name == clnt.Name && i.subscription_number == clnt.subscription_number);
        }

        //search by name
        public List<Clientes> Read(string name)
        {
            return db.clientes.Where(i => i.Name.Contains(name)).ToList();
        }
        //read by id for update and deleat
        public Clientes Read(int id)
        {
            return db.clientes.Where(i => i.id == id).Single();
        }
        //get the record
        public int GetRecord()
        {
            return db.clientes.Count();
        }
        //updatng information
        public string Update(int id, Clientes clntNew)
        {
            Clientes clnt = new Clientes();
          
            clnt = Read(id);
            clnt.Name = clntNew.Name;
            clnt.Type = clntNew.Type;
            clnt.Phone = clntNew.Phone;
            clnt.subscription_number = clntNew.subscription_number;
            clnt.Address = clntNew.Address;
            clnt.EmailAddress = clntNew.EmailAddress;
            clnt.DateofMembership = clntNew.DateofMembership;
            db.SaveChanges();
            return "Editing information completed successfully";

        }//deleat
        public string Deleat(int id)
        {
            Clientes clnt = Read(id);
            db.clientes.Remove(clnt);
            db.SaveChanges();
            return "Successfully Removed ";
        }

    }

    
}
