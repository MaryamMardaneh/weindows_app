﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinnessEntity;
using System.Data.Entity;

namespace DataAccessLayer
{
    public class DALemp
    {
        DataBace db = new DataBace();

        //creatine new employee
        public string Create(Employee emp)
        {
            if (!Read(emp))
            {
                if (emp.PersonelID.Length == 10)
                {
                    db.employees.Add(emp);
                    db.SaveChanges();
                    return "New Employee  Successfully Added!";
                }
                else
                {
                    return "The identification code is invalid";
                }
            }
            else
            {
                return "The Information Entered Is Already Existed!";
            }
        }
        //read all data
        public List<Employee> Read()
        {
            return db.employees.ToList();
        }
        //existing check
        public bool Read(Employee emp)
        {
            return db.employees.Any(i => i.Fullname == emp.Fullname && i.PersonelID == emp.PersonelID);
        }

        //search by name
        public List<Employee> Read(string name)
        {
            return db.employees.Where(i => i.Fullname.Contains( name)).ToList();
        }

        //counting the employes
        public int GetRecord()
        {
           return db.employees.Count();
        }
        //read by id for update and deleat
        public Employee Read(int id)
        {
            return db.employees.Where(i => i.id == id).Single();
        }

        //updatng information
        public string Update(int id, Employee empNew)
        {
            Employee emp = new Employee();
            emp = Read(id);
            emp.Fullname = empNew.Fullname;
            emp.Position = empNew.Phone;
            emp.Skills = empNew.Skills;
            emp.Position = empNew.Position;
            emp.Education = empNew.Education;
            emp.Address = empNew.Address;
            emp.DateofBirth = empNew.DateofBirth;
            emp.EmailAddress = empNew.EmailAddress;
            emp.PersonelID = empNew.PersonelID;
            emp.Phone = empNew.Phone;
            db.SaveChanges();
            return "Editing information completed successfully";

        }

        //deleat
        public string Deleat(int id)
        {
            Employee emp = Read(id);
            db.employees.Remove(emp);
            db.SaveChanges();
            return "Deletion Was Successful";
        }
    }
}
