﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinnessEntity;
using System.Data.Entity;

namespace DataAccessLayer
{
    public class dalContracts
    {

        DataBace db = new DataBace();
        //create new projrct
        public string Create(contract ctr)
        {
            if (!Read(ctr))
            {
                if (ctr.projrct_ID.Length==10)
                {
                    db.contracts.Add(ctr);
                    db.SaveChanges();
                    return "The contract was successfully registered ";
                }
                else
                {
                    return "The identification code is invalid !";
                }
            }
            else
            {
                return "The project ID entered is repetitive";
            }
           
        }

        //existance checking
        public bool Read(contract ctr)
        {
            return db.contracts.Any(i => i.projrct_ID == ctr.projrct_ID);
        }
        //read all data
        public List<contract> show()
        {
            return db.contracts.ToList();
        }

        //search by name
        public List<contract> Read(string name)
        {
            return db.contracts.Where(i => i.Project_name.Contains(name)).ToList();
        }

        //read by id for update and deleat
        public contract Read(int id)
        {
            return db.contracts.Where(i => i.ID == id).SingleOrDefault();
        }

        //get the number of recordes
        public int GetRecorde()
        {
            return db.contracts.Count();
        }
        

        //updatng information
        public string Update(int id, contract ctrNew)
        {
            contract ctr = new contract();
            ctr = Read(id);
            ctr.Project_name = ctrNew.Project_name;
            ctr.PicturePath = ctrNew.PicturePath;
            ctr.start_date = ctrNew.start_date;
            ctr.Delivery_Date = ctrNew.Delivery_Date;
            ctr.projrct_ID = ctrNew.projrct_ID;
            ctr.Price = ctrNew.Price;
            ctr.siret_number = ctrNew.siret_number;
            ctr.Grade = ctrNew.Grade;
            ctr.Type = ctrNew.Type;
            db.SaveChanges();
            return "Editing information completed successfully";
        }
        //Deleat
        public string Deleat(int id)
        {
            contract ctr = Read(id);
            db.contracts.Remove(ctr);
            db.SaveChanges();
            return "Successfully Removed ";
        }

    }
       

        
}

