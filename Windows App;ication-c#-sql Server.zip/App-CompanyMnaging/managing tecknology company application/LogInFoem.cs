﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinnessEntity;
using BussinessLogicLayer;


namespace managing_tecknology_company_application
{
    public partial class LogInFoem : Form
    {
        public LogInFoem()
        {
            InitializeComponent();
        }


        RegisterAdminForm newadmin = new RegisterAdminForm();
        mainForm m = new mainForm();
        BLLlogin blllogin = new BLLlogin();


        //dragform
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);
        //
        void Move()
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Close();
            guna2TextBox1.WordWrap = true;
        }

        private void LogInFoem_Load(object sender, EventArgs e)
        {
            if (blllogin.Login("", "") == 0)
            {
              label2.Visible = true;
            }
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if (blllogin.Login(guna2TextBox1.Text, guna2TextBox2.Text) == 1)
            {
                mainForm m = new mainForm();
                m.loginformUsername = "Welcome:)" + guna2TextBox1.Text;
                label3.Text = "Welcome";
                m.Show();
                this.Hide();
            }
            else
            {
                label3.Text = "Wrong username or password";
            } 
        }

        private void label2_Click(object sender, EventArgs e)
        {
            newadmin.ShowDialog();
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            Move();
        }

        private void LogInFoem_MouseDown(object sender, MouseEventArgs e)
        {
            Move();
        }

    }
}
