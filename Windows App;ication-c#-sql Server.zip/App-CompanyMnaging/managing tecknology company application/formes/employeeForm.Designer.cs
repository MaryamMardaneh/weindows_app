﻿
namespace managing_tecknology_company_application.formes
{
    partial class Form_employees
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2TextBox7_search = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2DataGridView1 = new Guna.UI2.WinForms.Guna2DataGridView();
            this.checkedListBox1_skills = new System.Windows.Forms.CheckedListBox();
            this.guna2ComboBox2_education = new Guna.UI2.WinForms.Guna2ComboBox();
            this.guna2ComboBox2_position = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.guna2DateTimePicker1_bod = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.guna2TextBox2_phone = new Guna.UI2.WinForms.Guna2TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.guna2TextBox1_personalId = new Guna.UI2.WinForms.Guna2TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.guna2TextBox4_emailaddress = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2TextBox3_address = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2TextBox5_fullname = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2TextBox6 = new Guna.UI2.WinForms.Guna2TextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.guna2GradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2GradientPanel1
            // 
            this.guna2GradientPanel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2GradientPanel1.Controls.Add(this.guna2TextBox7_search);
            this.guna2GradientPanel1.Controls.Add(this.guna2DataGridView1);
            this.guna2GradientPanel1.Controls.Add(this.checkedListBox1_skills);
            this.guna2GradientPanel1.Controls.Add(this.guna2ComboBox2_education);
            this.guna2GradientPanel1.Controls.Add(this.guna2ComboBox2_position);
            this.guna2GradientPanel1.Controls.Add(this.label9);
            this.guna2GradientPanel1.Controls.Add(this.guna2DateTimePicker1_bod);
            this.guna2GradientPanel1.Controls.Add(this.label8);
            this.guna2GradientPanel1.Controls.Add(this.label7);
            this.guna2GradientPanel1.Controls.Add(this.label6);
            this.guna2GradientPanel1.Controls.Add(this.label5);
            this.guna2GradientPanel1.Controls.Add(this.label4);
            this.guna2GradientPanel1.Controls.Add(this.label3);
            this.guna2GradientPanel1.Controls.Add(this.guna2TextBox2_phone);
            this.guna2GradientPanel1.Controls.Add(this.label2);
            this.guna2GradientPanel1.Controls.Add(this.guna2TextBox1_personalId);
            this.guna2GradientPanel1.Controls.Add(this.label1);
            this.guna2GradientPanel1.Controls.Add(this.guna2TextBox4_emailaddress);
            this.guna2GradientPanel1.Controls.Add(this.guna2TextBox3_address);
            this.guna2GradientPanel1.Controls.Add(this.guna2TextBox5_fullname);
            this.guna2GradientPanel1.Controls.Add(this.guna2GradientButton1);
            this.guna2GradientPanel1.Controls.Add(this.guna2TextBox6);
            this.guna2GradientPanel1.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(198)))), ((int)(((byte)(203)))));
            this.guna2GradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.guna2GradientPanel1.Name = "guna2GradientPanel1";
            this.guna2GradientPanel1.ShadowDecoration.Parent = this.guna2GradientPanel1;
            this.guna2GradientPanel1.Size = new System.Drawing.Size(1120, 720);
            this.guna2GradientPanel1.TabIndex = 0;
            // 
            // guna2TextBox7_search
            // 
            this.guna2TextBox7_search.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox7_search.DefaultText = "";
            this.guna2TextBox7_search.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox7_search.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox7_search.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox7_search.DisabledState.Parent = this.guna2TextBox7_search;
            this.guna2TextBox7_search.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox7_search.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2TextBox7_search.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox7_search.FocusedState.Parent = this.guna2TextBox7_search;
            this.guna2TextBox7_search.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox7_search.HoverState.Parent = this.guna2TextBox7_search;
            this.guna2TextBox7_search.Location = new System.Drawing.Point(0, 343);
            this.guna2TextBox7_search.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox7_search.Name = "guna2TextBox7_search";
            this.guna2TextBox7_search.PasswordChar = '\0';
            this.guna2TextBox7_search.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.guna2TextBox7_search.PlaceholderText = "Search here";
            this.guna2TextBox7_search.SelectedText = "";
            this.guna2TextBox7_search.ShadowDecoration.Parent = this.guna2TextBox7_search;
            this.guna2TextBox7_search.Size = new System.Drawing.Size(1120, 40);
            this.guna2TextBox7_search.TabIndex = 72;
            // 
            // guna2DataGridView1
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.guna2DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.guna2DataGridView1.BackgroundColor = System.Drawing.Color.Silver;
            this.guna2DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.guna2DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.guna2DataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.guna2DataGridView1.ColumnHeadersHeight = 4;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.guna2DataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            this.guna2DataGridView1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2DataGridView1.EnableHeadersVisualStyles = false;
            this.guna2DataGridView1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.Location = new System.Drawing.Point(0, 383);
            this.guna2DataGridView1.Name = "guna2DataGridView1";
            this.guna2DataGridView1.RowHeadersVisible = false;
            this.guna2DataGridView1.RowHeadersWidth = 51;
            this.guna2DataGridView1.RowTemplate.Height = 24;
            this.guna2DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.guna2DataGridView1.Size = new System.Drawing.Size(1120, 337);
            this.guna2DataGridView1.TabIndex = 71;
            this.guna2DataGridView1.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.Default;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView1.ThemeStyle.BackColor = System.Drawing.Color.Silver;
            this.guna2DataGridView1.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.Height = 4;
            this.guna2DataGridView1.ThemeStyle.ReadOnly = false;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.guna2DataGridView1.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView1.ThemeStyle.RowsStyle.Height = 24;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView1.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.guna2DataGridView1_CellMouseClick_1);
            // 
            // checkedListBox1_skills
            // 
            this.checkedListBox1_skills.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkedListBox1_skills.ForeColor = System.Drawing.Color.Gray;
            this.checkedListBox1_skills.FormattingEnabled = true;
            this.checkedListBox1_skills.Items.AddRange(new object[] {
            "Front_end",
            "Back_End",
            "UX",
            "UI",
            "IOS App",
            "Android App",
            "Windows application"});
            this.checkedListBox1_skills.Location = new System.Drawing.Point(508, 184);
            this.checkedListBox1_skills.Name = "checkedListBox1_skills";
            this.checkedListBox1_skills.Size = new System.Drawing.Size(167, 55);
            this.checkedListBox1_skills.TabIndex = 69;
            // 
            // guna2ComboBox2_education
            // 
            this.guna2ComboBox2_education.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2ComboBox2_education.BackColor = System.Drawing.Color.Transparent;
            this.guna2ComboBox2_education.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.guna2ComboBox2_education.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.guna2ComboBox2_education.FocusedColor = System.Drawing.Color.Empty;
            this.guna2ComboBox2_education.FocusedState.Parent = this.guna2ComboBox2_education;
            this.guna2ComboBox2_education.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.guna2ComboBox2_education.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.guna2ComboBox2_education.FormattingEnabled = true;
            this.guna2ComboBox2_education.HoverState.Parent = this.guna2ComboBox2_education;
            this.guna2ComboBox2_education.ItemHeight = 30;
            this.guna2ComboBox2_education.Items.AddRange(new object[] {
            "Bts",
            "Master",
            "MBA",
            "DBA",
            "Stage",
            "Diplome"});
            this.guna2ComboBox2_education.ItemsAppearance.Parent = this.guna2ComboBox2_education;
            this.guna2ComboBox2_education.Location = new System.Drawing.Point(171, 184);
            this.guna2ComboBox2_education.Name = "guna2ComboBox2_education";
            this.guna2ComboBox2_education.ShadowDecoration.Parent = this.guna2ComboBox2_education;
            this.guna2ComboBox2_education.Size = new System.Drawing.Size(167, 36);
            this.guna2ComboBox2_education.TabIndex = 68;
            // 
            // guna2ComboBox2_position
            // 
            this.guna2ComboBox2_position.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2ComboBox2_position.BackColor = System.Drawing.Color.Transparent;
            this.guna2ComboBox2_position.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.guna2ComboBox2_position.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.guna2ComboBox2_position.FocusedColor = System.Drawing.Color.Empty;
            this.guna2ComboBox2_position.FocusedState.Parent = this.guna2ComboBox2_position;
            this.guna2ComboBox2_position.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.guna2ComboBox2_position.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.guna2ComboBox2_position.FormattingEnabled = true;
            this.guna2ComboBox2_position.HoverState.Parent = this.guna2ComboBox2_position;
            this.guna2ComboBox2_position.ItemHeight = 30;
            this.guna2ComboBox2_position.Items.AddRange(new object[] {
            "Manager",
            "Junior Developer",
            "Senior Developer",
            "Receptionist",
            "Countenent"});
            this.guna2ComboBox2_position.ItemsAppearance.Parent = this.guna2ComboBox2_position;
            this.guna2ComboBox2_position.Location = new System.Drawing.Point(890, 110);
            this.guna2ComboBox2_position.Name = "guna2ComboBox2_position";
            this.guna2ComboBox2_position.ShadowDecoration.Parent = this.guna2ComboBox2_position;
            this.guna2ComboBox2_position.Size = new System.Drawing.Size(163, 36);
            this.guna2ComboBox2_position.TabIndex = 67;
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Gray;
            this.label9.Location = new System.Drawing.Point(776, 203);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(87, 15);
            this.label9.TabIndex = 66;
            this.label9.Text = "Date of Birth";
            // 
            // guna2DateTimePicker1_bod
            // 
            this.guna2DateTimePicker1_bod.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2DateTimePicker1_bod.BackColor = System.Drawing.Color.DarkGray;
            this.guna2DateTimePicker1_bod.BorderColor = System.Drawing.Color.DimGray;
            this.guna2DateTimePicker1_bod.BorderRadius = 7;
            this.guna2DateTimePicker1_bod.CheckedState.Parent = this.guna2DateTimePicker1_bod;
            this.guna2DateTimePicker1_bod.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.guna2DateTimePicker1_bod.FocusedColor = System.Drawing.Color.Gray;
            this.guna2DateTimePicker1_bod.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2DateTimePicker1_bod.ForeColor = System.Drawing.Color.White;
            this.guna2DateTimePicker1_bod.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.guna2DateTimePicker1_bod.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.guna2DateTimePicker1_bod.HoverState.Parent = this.guna2DateTimePicker1_bod;
            this.guna2DateTimePicker1_bod.Location = new System.Drawing.Point(890, 182);
            this.guna2DateTimePicker1_bod.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.guna2DateTimePicker1_bod.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.guna2DateTimePicker1_bod.Name = "guna2DateTimePicker1_bod";
            this.guna2DateTimePicker1_bod.ShadowDecoration.Parent = this.guna2DateTimePicker1_bod;
            this.guna2DateTimePicker1_bod.Size = new System.Drawing.Size(163, 55);
            this.guna2DateTimePicker1_bod.TabIndex = 65;
            this.guna2DateTimePicker1_bod.Value = new System.DateTime(2022, 3, 9, 14, 49, 45, 685);
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Gray;
            this.label8.Location = new System.Drawing.Point(409, 205);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 15);
            this.label8.TabIndex = 64;
            this.label8.Text = "Skills:";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Gray;
            this.label7.Location = new System.Drawing.Point(68, 205);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 15);
            this.label7.TabIndex = 63;
            this.label7.Text = "Education:";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gray;
            this.label6.Location = new System.Drawing.Point(800, 120);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 15);
            this.label6.TabIndex = 62;
            this.label6.Text = "Position:";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gray;
            this.label5.Location = new System.Drawing.Point(423, 122);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 15);
            this.label5.TabIndex = 61;
            this.label5.Text = "Address:";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gray;
            this.label4.Location = new System.Drawing.Point(118, 122);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(25, 15);
            this.label4.TabIndex = 60;
            this.label4.Text = "ID:";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gray;
            this.label3.Location = new System.Drawing.Point(777, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 15);
            this.label3.TabIndex = 59;
            this.label3.Text = "Adress Mail:";
            // 
            // guna2TextBox2_phone
            // 
            this.guna2TextBox2_phone.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2TextBox2_phone.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox2_phone.DefaultText = "";
            this.guna2TextBox2_phone.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox2_phone.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox2_phone.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox2_phone.DisabledState.Parent = this.guna2TextBox2_phone;
            this.guna2TextBox2_phone.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox2_phone.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox2_phone.FocusedState.Parent = this.guna2TextBox2_phone;
            this.guna2TextBox2_phone.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox2_phone.HoverState.Parent = this.guna2TextBox2_phone;
            this.guna2TextBox2_phone.Location = new System.Drawing.Point(508, 34);
            this.guna2TextBox2_phone.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox2_phone.Name = "guna2TextBox2_phone";
            this.guna2TextBox2_phone.PasswordChar = '\0';
            this.guna2TextBox2_phone.PlaceholderText = "Phone number";
            this.guna2TextBox2_phone.SelectedText = "";
            this.guna2TextBox2_phone.ShadowDecoration.Parent = this.guna2TextBox2_phone;
            this.guna2TextBox2_phone.Size = new System.Drawing.Size(167, 30);
            this.guna2TextBox2_phone.TabIndex = 53;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gray;
            this.label2.Location = new System.Drawing.Point(433, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 15);
            this.label2.TabIndex = 58;
            this.label2.Text = "Phone:";
            // 
            // guna2TextBox1_personalId
            // 
            this.guna2TextBox1_personalId.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2TextBox1_personalId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox1_personalId.DefaultText = "";
            this.guna2TextBox1_personalId.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox1_personalId.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox1_personalId.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox1_personalId.DisabledState.Parent = this.guna2TextBox1_personalId;
            this.guna2TextBox1_personalId.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox1_personalId.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox1_personalId.FocusedState.Parent = this.guna2TextBox1_personalId;
            this.guna2TextBox1_personalId.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox1_personalId.HoverState.Parent = this.guna2TextBox1_personalId;
            this.guna2TextBox1_personalId.Location = new System.Drawing.Point(171, 110);
            this.guna2TextBox1_personalId.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox1_personalId.Name = "guna2TextBox1_personalId";
            this.guna2TextBox1_personalId.PasswordChar = '\0';
            this.guna2TextBox1_personalId.PlaceholderText = "Enter the ID";
            this.guna2TextBox1_personalId.SelectedText = "";
            this.guna2TextBox1_personalId.ShadowDecoration.Parent = this.guna2TextBox1_personalId;
            this.guna2TextBox1_personalId.Size = new System.Drawing.Size(167, 30);
            this.guna2TextBox1_personalId.TabIndex = 52;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gray;
            this.label1.Location = new System.Drawing.Point(94, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 15);
            this.label1.TabIndex = 57;
            this.label1.Text = "Nmae:";
            // 
            // guna2TextBox4_emailaddress
            // 
            this.guna2TextBox4_emailaddress.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2TextBox4_emailaddress.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox4_emailaddress.DefaultText = "";
            this.guna2TextBox4_emailaddress.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox4_emailaddress.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox4_emailaddress.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox4_emailaddress.DisabledState.Parent = this.guna2TextBox4_emailaddress;
            this.guna2TextBox4_emailaddress.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox4_emailaddress.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox4_emailaddress.FocusedState.Parent = this.guna2TextBox4_emailaddress;
            this.guna2TextBox4_emailaddress.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox4_emailaddress.HoverState.Parent = this.guna2TextBox4_emailaddress;
            this.guna2TextBox4_emailaddress.Location = new System.Drawing.Point(890, 32);
            this.guna2TextBox4_emailaddress.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox4_emailaddress.Name = "guna2TextBox4_emailaddress";
            this.guna2TextBox4_emailaddress.PasswordChar = '\0';
            this.guna2TextBox4_emailaddress.PlaceholderText = "Email Address";
            this.guna2TextBox4_emailaddress.SelectedText = "";
            this.guna2TextBox4_emailaddress.ShadowDecoration.Parent = this.guna2TextBox4_emailaddress;
            this.guna2TextBox4_emailaddress.Size = new System.Drawing.Size(163, 30);
            this.guna2TextBox4_emailaddress.TabIndex = 55;
            // 
            // guna2TextBox3_address
            // 
            this.guna2TextBox3_address.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2TextBox3_address.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox3_address.DefaultText = "";
            this.guna2TextBox3_address.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox3_address.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox3_address.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox3_address.DisabledState.Parent = this.guna2TextBox3_address;
            this.guna2TextBox3_address.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox3_address.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox3_address.FocusedState.Parent = this.guna2TextBox3_address;
            this.guna2TextBox3_address.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox3_address.HoverState.Parent = this.guna2TextBox3_address;
            this.guna2TextBox3_address.Location = new System.Drawing.Point(508, 110);
            this.guna2TextBox3_address.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox3_address.Name = "guna2TextBox3_address";
            this.guna2TextBox3_address.PasswordChar = '\0';
            this.guna2TextBox3_address.PlaceholderText = "Address";
            this.guna2TextBox3_address.SelectedText = "";
            this.guna2TextBox3_address.ShadowDecoration.Parent = this.guna2TextBox3_address;
            this.guna2TextBox3_address.Size = new System.Drawing.Size(167, 38);
            this.guna2TextBox3_address.TabIndex = 54;
            // 
            // guna2TextBox5_fullname
            // 
            this.guna2TextBox5_fullname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2TextBox5_fullname.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox5_fullname.DefaultText = "";
            this.guna2TextBox5_fullname.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox5_fullname.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox5_fullname.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox5_fullname.DisabledState.Parent = this.guna2TextBox5_fullname;
            this.guna2TextBox5_fullname.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox5_fullname.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox5_fullname.FocusedState.Parent = this.guna2TextBox5_fullname;
            this.guna2TextBox5_fullname.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox5_fullname.HoverState.Parent = this.guna2TextBox5_fullname;
            this.guna2TextBox5_fullname.Location = new System.Drawing.Point(171, 34);
            this.guna2TextBox5_fullname.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox5_fullname.Name = "guna2TextBox5_fullname";
            this.guna2TextBox5_fullname.PasswordChar = '\0';
            this.guna2TextBox5_fullname.PlaceholderText = "Enter full name ";
            this.guna2TextBox5_fullname.SelectedText = "";
            this.guna2TextBox5_fullname.ShadowDecoration.Parent = this.guna2TextBox5_fullname;
            this.guna2TextBox5_fullname.Size = new System.Drawing.Size(167, 30);
            this.guna2TextBox5_fullname.TabIndex = 56;
            // 
            // guna2GradientButton1
            // 
            this.guna2GradientButton1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2GradientButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2GradientButton1.BorderRadius = 20;
            this.guna2GradientButton1.CheckedState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.CustomImages.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(90)))), ((int)(((byte)(165)))));
            this.guna2GradientButton1.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton1.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton1.HoverState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Location = new System.Drawing.Point(493, 270);
            this.guna2GradientButton1.Name = "guna2GradientButton1";
            this.guna2GradientButton1.ShadowDecoration.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Size = new System.Drawing.Size(182, 45);
            this.guna2GradientButton1.TabIndex = 23;
            this.guna2GradientButton1.Text = "Save";
            this.guna2GradientButton1.Click += new System.EventHandler(this.guna2PictureBox1_Click);
            // 
            // guna2TextBox6
            // 
            this.guna2TextBox6.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox6.DefaultText = "";
            this.guna2TextBox6.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox6.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox6.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox6.DisabledState.Parent = this.guna2TextBox6;
            this.guna2TextBox6.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox6.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox6.FocusedState.Parent = this.guna2TextBox6;
            this.guna2TextBox6.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox6.HoverState.Parent = this.guna2TextBox6;
            this.guna2TextBox6.Location = new System.Drawing.Point(53, 927);
            this.guna2TextBox6.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.guna2TextBox6.Name = "guna2TextBox6";
            this.guna2TextBox6.PasswordChar = '\0';
            this.guna2TextBox6.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.guna2TextBox6.PlaceholderText = "Search Here";
            this.guna2TextBox6.SelectedText = "";
            this.guna2TextBox6.ShadowDecoration.Parent = this.guna2TextBox6;
            this.guna2TextBox6.Size = new System.Drawing.Size(989, 63);
            this.guna2TextBox6.TabIndex = 21;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.BackColor = System.Drawing.Color.White;
            this.contextMenuStrip1.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold);
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editToolStripMenuItem,
            this.deleatToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(122, 52);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(121, 24);
            this.editToolStripMenuItem.Text = "Edit";
            this.editToolStripMenuItem.Click += new System.EventHandler(this.editToolStripMenuItem_Click);
            // 
            // deleatToolStripMenuItem
            // 
            this.deleatToolStripMenuItem.Name = "deleatToolStripMenuItem";
            this.deleatToolStripMenuItem.Size = new System.Drawing.Size(121, 24);
            this.deleatToolStripMenuItem.Text = "Deleat";
            this.deleatToolStripMenuItem.Click += new System.EventHandler(this.deleatToolStripMenuItem_Click);
            // 
            // Form_employees
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1120, 720);
            this.Controls.Add(this.guna2GradientPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form_employees";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "form1";
            this.Load += new System.EventHandler(this.Form_employees_Load);
            this.guna2GradientPanel1.ResumeLayout(false);
            this.guna2GradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox6;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleatToolStripMenuItem;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox7_search;
        private Guna.UI2.WinForms.Guna2DataGridView guna2DataGridView1;
        private System.Windows.Forms.CheckedListBox checkedListBox1_skills;
        private Guna.UI2.WinForms.Guna2ComboBox guna2ComboBox2_education;
        private Guna.UI2.WinForms.Guna2ComboBox guna2ComboBox2_position;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2DateTimePicker guna2DateTimePicker1_bod;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox2_phone;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox1_personalId;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox4_emailaddress;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox3_address;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox5_fullname;
    }
}