﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinnessEntity;
using BussinessLogicLayer;
using System.IO;
using System.Drawing.Printing;



namespace managing_tecknology_company_application.formes
{
    public partial class ContractForm : Form
    {
        public ContractForm()
        {
            InitializeComponent();
        }
        OpenFileDialog opf = new OpenFileDialog();
        BLLContract bllcontract = new BLLContract();


        int id;
        Image pic;
        bool flag = true;
        BLLclientes bLLclientes = new BLLclientes();

        void DGV()
        {
            guna2DataGridView1.DataSource = null;
            guna2DataGridView1.DataSource = bllcontract.Read();
            guna2DataGridView1.Columns["id"].Visible = false;
            guna2DataGridView1.Columns["PicturePath"].Visible = false;
        }

        void Clear()
        {

            foreach (var item in Controls)
            {
                if (item.GetType().ToString() == "Guna.UI2.WinForms.Guna2TextBox")
                {
                    (item as TextBox).Text = "";
                }
            }

        }

        //pic saving
        string SavePic(string projectID)
        {
            string appPath = Path.GetDirectoryName(Application.ExecutablePath) + @"\Pictures\";
            if (Directory.Exists(appPath) == false)
            {
                Directory.CreateDirectory(appPath);
            }
            string scanCtr = projectID + ".jpg";
            try
            {
                
                string filepath = opf.FileName;  
                File.Copy(filepath, appPath + scanCtr); 
            }
            catch (Exception exp)
            {
                MessageBox.Show("Unable to save file " + exp.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return appPath + scanCtr;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void guna2GradientButton1_save_Click(object sender, EventArgs e)
        {
            contract ctr = new contract();
            Clientes clnt = new Clientes();
            ctr.Project_name = guna2TextBox5_name.Text;
            ctr.projrct_ID = guna2TextBox1_prijID.Text;
            ctr.Price = guna2TextBox_PRIce.Text;
            //there's a relation between clients and their projects
            ctr.siret_number = clnt.subscription_number;
            ctr.siret_number = guna2TextBox2_ownerID.Text;
            ctr.start_date = guna2DateTimePicker1_start.Value.Date;
            ctr.Delivery_Date = guna2DateTimePicker1_end.Value.Date;
            ctr.Type = checkedListBox1_type.SelectedItems.ToString();
            ctr.Grade = ((byte)numericUpDown1.Value);
            ctr.PicturePath = SavePic(guna2TextBox1_prijID.Text);

            if(flag)
            {
                //create
                MessageBox.Show(bllcontract.Create(ctr));
            }
            else if (!flag)
            {
                //update
                MessageBox.Show(bllcontract.Update(id, ctr));
                flag = true;
                guna2GradientButton1_save.Text = "Save";
            }
               DGV();
               Clear();
        }

        private void guna2TileButton1_upload_Click(object sender, EventArgs e)
        {
           opf.Filter = "JPG(*.JPG)|*.JPG";

            if (opf.ShowDialog() == DialogResult.OK)
            {
                pic = Image.FromFile(opf.FileName);
                pictureBox2.Image = pic;
            }
        }

        private void ContractForm_Load(object sender, EventArgs e)
        {
            DGV();
        }

        private void guna2DataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.ColumnIndex != -1 && e.RowIndex != -1 && e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                contextMenuStrip1.Show(Cursor.Position.X, Cursor.Position.Y);
            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            contract ctr = bllcontract.Read(id);
            ctr.Project_name = guna2TextBox5_name.Text;
            ctr.projrct_ID = guna2TextBox1_prijID.Text;
            ctr.Price = guna2TextBox_PRIce.Text;
            ctr.Grade = ((byte)numericUpDown1.Value);
            ctr.Type = checkedListBox1_type.SelectedItems.ToString();
            ctr.siret_number = guna2TextBox2_ownerID.Text;
            ctr.start_date = guna2DateTimePicker1_start.Value.Date;
            ctr.Delivery_Date = guna2DateTimePicker1_end.Value.Date;
            flag = false;
            guna2GradientButton1_save.Text = "Edit New Informations";

        }


        private void deleatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bllcontract.Deleat(id);
            DGV();
        }

        private void guna2TextBox7_search_TextChanged(object sender, EventArgs e)
        {
            guna2DataGridView1.DataSource = null;
            guna2DataGridView1.DataSource = bllcontract.Read(guna2TextBox7_search.Text);
        }

        private void guna2DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                id = int.Parse(guna2DataGridView1.Rows[e.RowIndex].Cells["id"].Value.ToString());
            }
            catch (Exception)
            {

            }
            contract ctr = bllcontract.Read(id);
            pictureBox2.Image = Image.FromFile(ctr.PicturePath);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void guna2DateTimePicker1_end_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void checkedListBox1_type_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void guna2DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void guna2TextBox2_ownerID_TextChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void guna2TextBox_PRIce_TextChanged(object sender, EventArgs e)
        {

        }

        private void guna2TextBox5_name_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void guna2DateTimePicker1_start_ValueChanged(object sender, EventArgs e)
        {

        }

        private void guna2TextBox1_prijID_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox2_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                contextMenuStrip2.Show(Cursor.Position.X, Cursor.Position.Y);
            }
        }

        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {

            printContract();
        }

        private void doc_printPage(object sender, PrintPageEventArgs e)
        {
            Bitmap bm = new Bitmap(pictureBox2.Width, pictureBox2.Height);
            pictureBox2.DrawToBitmap(bm, new Rectangle(0, 0, pictureBox2.Width, pictureBox2.Height));
            e.Graphics.DrawImage(bm, 0, 0);
            bm.Dispose();
        }
        private void printContract()
        {
            PrintDialog pd = new PrintDialog();
            PrintDocument doc = new PrintDocument();
            doc.PrintPage += doc_printPage;

            pd.Document = doc;
            if (pd.ShowDialog() == DialogResult.OK)
            {
                doc.Print();
            }
        }
       
    }
}
