﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinnessEntity;
using BussinessLogicLayer;
using System.Windows.Forms.DataVisualization.Charting;

namespace managing_tecknology_company_application.formes
{
    public partial class analyse : Form
    {
        public analyse()
        {
            InitializeComponent();
        }

        BLLAnalyse BLLAnalyse = new BLLAnalyse();

        private void analyse_Load_1(object sender, EventArgs e)
        {
            foreach (var series in chart1.Series) { series.Points.Clear(); }
            
            List<double> income = BLLAnalyse.Read();

            for (int i = 0; i < income.Count; i++)
              {
                    chart1.Series["Income"].Points.AddXY(2022 + i, income[i]);
              }

        }

        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            YearIncome income = new YearIncome();
            income.Year = guna2TextBox2.Text;
            income.Income = Convert.ToDouble(guna2TextBox1.Text);
            BLLAnalyse.Create(income);
            
            foreach (var series in chart1.Series) { series.Points.Clear(); }
            try
            {
                List<double> Income =BLLAnalyse.Read();

                for (int i = 0; i < Income.Count; i++)
                {
                    chart1.Series["Imcome"].Points.AddXY(2022 + i, Income[i]);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("It wasn't successful", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
