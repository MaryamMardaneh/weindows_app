﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BussinessLogicLayer;
using BusinnessEntity;
using System.Runtime.InteropServices;
using Guna.UI2.WinForms;

namespace managing_tecknology_company_application
{
    public partial class mainForm : Form
    {
       
        public mainForm()
        {
            InitializeComponent();
            
        }

        

        public void loadForm(object form)
        {
            if (this.panel_desktop.Controls.Count > 0)
            {
                this.panel_desktop.Controls.RemoveAt(0);
                Form f1 = form as Form;
                f1.TopLevel = false;
                f1.Dock = DockStyle.Fill;
                this.panel_desktop.Controls.Add(f1);
                this.panel_desktop.Tag = f1;
                f1.Show();
            }
        }

        //Drag Form
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);


        public string loginformUsername;

        

        private void guna2Button1_Click_2(object sender, EventArgs e)
        {
            
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {

            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        
        private void guna2CustomGradientPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        public void mainForm_load(object sender,EventArgs e)
        {

            

        }

        private void guna2Button11_Click(object sender, EventArgs e)
        {
            loadForm(new formes.ContractForm());
        }

        private void guna2Button10_Click(object sender, EventArgs e)
        {
            loadForm(new formes.Form_employees());
        }

        private void guna2Button9_Click(object sender, EventArgs e)
        {
            loadForm(new formes.ClientesForm());
        }

        private void guna2Button8_Click(object sender, EventArgs e)
        {
            loadForm(new formes.analyse());
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            this.Close();
            mainForm form = new mainForm();
            form.Show();
        }

        private void guna2Button6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void guna2CustomGradientPanel1_Paint(object sender, PaintEventArgs e)
        { 
            
        }

        private void panel_desktop_Paint(object sender, PaintEventArgs e)
        {

        }

        private void mainForm_Load_1(object sender, EventArgs e)
        {
            //display the number of employees from database
            BLemp bLemp = new BLemp();
            label2.Visible = true;
            int q = bLemp.GetRecord();
            label2.Text = q.ToString();
            label2.ForeColor = Color.Gray;
            //display the nember of contract from database
            BLLclientes bLLclientes = new BLLclientes();
            label4.Visible = true;
            int q1 = bLLclientes.GetRecord();
            label4.Text = q1.ToString();
            label4.ForeColor = Color.Gray;
            //display the of clientes from database
            BLLContract bLLContract = new BLLContract();
            label6.Visible = true;
            int q2 = bLLContract.GetRecord();
            label6.Text = q2.ToString();
            label6.ForeColor = Color.White;

        }
    }
    }
    

